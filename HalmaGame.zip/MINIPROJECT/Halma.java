//Gregory Ghiroli , Matt Ross
//ISTE 121 
// 2/10/2016

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;



import java.util.ArrayList; 
import java.util.List;


/**Description 

@author Gregory Ghiroli  and Matt Ross
@version 1 Build February 10, 2016




Halma is an 8 by 8 board game that requires players to take and make pieces via the spaces they click
Player with the most game pieces win the game

*/
public class Halma extends JFrame implements ActionListener{
 
 
 //Attributes MenuBAR
   private JMenuBar menuBar;
   private JMenu filemenu, editmenu;
   private JMenuItem exitAction, themeAction, clearAction, aboutAction, newGameAction;
   private char[][] field;
   private int i;
   private int j;
   boolean pass = false;
   JButton [][] button;
   int selectedX = -1;
   int selectedY = -1;
   JPanel gamePanel, winPanel;
   JLabel winningLabel;
   private Color pcolor, p2color;
   
   
   
  
  
  
   int currentPlayer = -1;
   ArrayList<Object> Player = new ArrayList<Object>();
   ArrayList<Object> Player2 = new ArrayList<Object>();
   
    
   ArrayList<Object>WinP = new ArrayList<Object>();
   ArrayList<Object>WinP2 = new ArrayList<Object>();

   


   

   public static void main(String []args)
   {
   
      new Halma();
      
       
   } //end of main
 
   public Halma(){
   
   //GUI basics
      setTitle(" Halma ");
   
      setSize(800,800);
   
      setLocationRelativeTo(null);
   
   
   //GUI menu bar
   
   
      menuBar = new JMenuBar();
   
   
      setJMenuBar(menuBar);
   
   
   //GUI Menu bar items
      filemenu = new JMenu("File");
      editmenu = new JMenu("About");
      menuBar.add(filemenu);
      menuBar.add(editmenu);
   
   
   //GUI Actions
   
      exitAction = new JMenuItem("Exit");
      themeAction = new JMenuItem("Themes");
      clearAction = new JMenuItem("Clear board");
      aboutAction = new JMenuItem(" About");
      newGameAction = new JMenuItem("Start Game");
      
    //Add to FileMenu  
      filemenu.add(themeAction);
      filemenu.add(clearAction);
      filemenu.add(newGameAction);
      filemenu.add(exitAction);
      
      
   //Add to AboutMenu
      
      editmenu.add(aboutAction);
      
   
      
      // declare field 2D array.
      field = new char[8][8];
   
      // Initialize with whitespaces
      for (int i = 0; i < 8; ++i)
         for (int j = 0; j < 8; ++j)
            field[i][j] = ' ';
      
      // declare panel 2D array
      button = new JButton[8][8];
      
      gamePanel = new JPanel( new GridLayout( 8, 8, 2, 2 ) );
         
               
      currentPlayer = 0;
      
      // for loop to make all of the JButtons on the board
      for( int i=0; i<8; i++ ){ 
         for( int j=0; j<8; j++ ){
            button[i][j] = new JButton();
            button[i][j].setBackground( Color.GRAY );
            String setx = i + " , " + j + " ";
            button[i][j].setText(setx);
            gamePanel.add( button[i][j] );
            button[i][j].addActionListener(this);
           
                       
            
         }
      }
      
   
   
   
      add(gamePanel,BorderLayout.CENTER);
   
   
   //Winning Labels
   
      JPanel winPanel = new JPanel();
      winningLabel = new JLabel();
      winningLabel.setVisible(false);
   
   
      winPanel.add(winningLabel, BorderLayout.CENTER);
   
      add(winPanel, BorderLayout.SOUTH);
   
   
   //GUI visible
      add(menuBar, BorderLayout.NORTH);
      setVisible(true);
   
      setDefaultCloseOperation(EXIT_ON_CLOSE);
   //ActionListeners
   
      newGameAction.addActionListener(this);
      exitAction.addActionListener(this);
         //  button.addActionListener(this);
        // button[i][j].addActionListener(this);
   
   
   
   
   
   }//end of Halma ()
   
 
         
   
   public void  actionPerformed(ActionEvent ae)
   {
      Object choice = ae.getSource();
      
      
      if(choice == newGameAction)
      {
         //red pieces Player 1         
         Player.add(button[0][0]);  
         Player.add(button[0][1]);
         Player.add(button[0][2]);
         Player.add(button[0][3]);
         Player.add(button[1][0]);
         Player.add(button[1][1]);
         Player.add(button[1][2]);
         Player.add(button[2][0]);
         Player.add(button[2][1]);
         Player.add(button[3][0]);
         
          //for the win object
         
         
         WinP.add(button[4][7]);
         WinP.add(button[5][6]);
         WinP.add(button[5][7]);
         WinP.add(button[6][5]);
         WinP.add(button[6][6]);
         WinP.add(button[6][7]);
         WinP.add(button[7][4]);
         WinP.add(button[7][5]);
         WinP.add(button[7][6]);
         WinP.add(button[7][7]);
      
      
         
         
         
         
         
         
         JButton tempButton = null;
         for(int i = 0; i < Player.size(); i++) {
            tempButton = (JButton)Player.get(i);
            tempButton.setBackground(Color.RED);
         }
                     
         //yellow piece Player 2         
         Player2.add(button[4][7]);
         Player2.add(button[5][6]);
         Player2.add(button[5][7]);
         Player2.add(button[6][5]);
         Player2.add(button[6][6]);
         Player2.add(button[6][7]);
         Player2.add(button[7][4]);
         Player2.add(button[7][5]);
         Player2.add(button[7][6]);
         Player2.add(button[7][7]);
         
         WinP2.add(button[0][0]);  
         WinP2.add(button[0][1]);
         WinP2.add(button[0][2]);
         WinP2.add(button[0][3]);
         WinP2.add(button[1][0]);
         WinP2.add(button[1][1]);
         WinP2.add(button[1][2]);
         WinP2.add(button[2][0]);
         WinP2.add(button[2][1]);
         WinP2.add(button[3][0]);
      
         
         
         
         
         
         for(int i = 0; i < Player2.size(); i++) {
            tempButton = (JButton)Player2.get(i);
            tempButton.setBackground(Color.YELLOW);
         }
         
         
         //Default background color
         
         gamePanel.setBackground( Color.BLACK);             
         
         
         
      }//end of newGameAction
      if(choice == exitAction)
      {
         System.out.println(" Now leaving");
         System.exit(3);
      
      
      }
      
      // check if there is a selected coord
      if(selectedX != -1 && selectedY != -1) {
         
         int x = -1;
         int y = -1;
         
         // find the coord of the clicked button
         for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
               if(currentPlayer == 0 && button[i][j] == choice && (i == selectedX || i == selectedX + 1) && (j == selectedY || j == selectedY + 1)) {
                  x = i;
                  y = j;
                  if(!(Player.contains(button[i][j]))&&!(Player2.contains(button[i][j]))){
                     Player.remove(button[selectedX][selectedY]);
                     button[selectedX][selectedY].setBackground(Color.GRAY);
                     Player.add(button[i][j]);
                     button[i][j].setBackground(Color.RED);
                     System.out.println("P1 can move");
                     
                     
                     if(Player.contains(button[i][j]) == WinP.contains(button[i][j]))
                     {
                                                   winningLabel.setText(" Player one Wins");
                           winningLabel.setVisible(true);
                           System.out.println("Player one Wins");
                        
                        
                     }//end of player
                  
                     
                     
                  }
               }
               else if(currentPlayer == 1 && button[i][j] == choice && (i == selectedX || i == selectedX - 1) && (j == selectedY || j == selectedY - 1)) {
                  x = i;
                  y = j;
                  if(!(Player2.contains(button[i][j]))&&!(Player.contains(button[i][j]))){
                     Player2.remove(button[selectedX][selectedY]);
                     button[selectedX][selectedY].setBackground(Color.GRAY);
                     Player2.add(button[i][j]);
                     button[i][j].setBackground(Color.YELLOW);
                     System.out.println("p2 can move");
                     
                     if(Player2.contains(WinP2))
                     {
                     
                        winningLabel.setText(" Player one Wins");
                        winningLabel.setVisible(true);
                        System.out.println("Player one Wins");
                     
                     
                     }//end of player
                  
                     
                     
                     
                  }
               }
            }
         }
         
         // reset the selected button and pass the turn to the other player
         if(currentPlayer == 0 && x != -1 && y != -1) {
            selectedX = selectedY = -1;
            currentPlayer++;
         }
         else if(currentPlayer == 1 && x != -1 && y != -1) {
            selectedX = selectedY = -1;
            currentPlayer--;
         }
      }
      // if there is not a selected player
      else {
         int x = -1;
         int y = -1;
         
         // check to see if it is a piece controlled by the current player
         for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
               if(currentPlayer == 0 && button[i][j] == choice && Player.contains(choice)) {
                  x = i;
                  y = j;
               }
               else if(currentPlayer == 1 && button[i][j] == choice && Player2.contains(choice)) {
                  x = i;
                  y = j;
               }
            }
         }
         
         // if it is player 1 select those coords
         if(currentPlayer == 0) {
            if(x != -1 && y != -1) {
               System.out.println("button[" + x + ", " + y + "] has been selected by player 1");
               selectedX = x;
               selectedY = y;
               
               if(Player.contains(WinP))
               {
                  
                  winningLabel.setText(" Player one Wins");
                  winningLabel.setVisible(true);
                     
                  
               }//end of player
                  
                  
            
               
               
            }
         }
         // if it is player 2 select those coords
         else {
            if(x != -1 && y != -1) {
               System.out.println("button[" + x + ", " + y + "] has been selected by player 2");
               selectedX = x;
               selectedY = y;
            }
         }
      }
      
   }//end of Action Performed
   
   class Player1 extends JButton{
   
   
      int i;
      int j;
      JButton button;
   
   
      Player1(int _i, int _j){
      
         this.i = _i;
      
         this.j = _j;
      
      
      
      }//end of Player1 consturctor 
   
   
      public void swap()
      {
      
      
      
      
      
      
      }//end of swap()
   
   
   
   
   
   }//end of Player1 class 
   
   
     
   
 
 
}// end of public class


























