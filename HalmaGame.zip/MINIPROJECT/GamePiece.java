class GamePiece{

int player = 2;
int i;
int j;
int count = 10;




}//end of GamePiece